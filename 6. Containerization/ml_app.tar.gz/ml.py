﻿import pickle
from flask import Flask, request
import json


app = Flask(__name__)
with open('model_weight_height.pkl', 'rb') as f:
    lr = pickle.load(f)


@app.route('/', methods=['POST'])
def predict():
    weight = request.get_json()['weight']
    if type(weight) != int or type(weight) != float:
        return json.dumps('Not a number, try again!')
    return json.dumps(round(*lr.predict([[weight]]), 1))


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
